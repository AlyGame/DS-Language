@echo off
set DS_HEADER_VERSION="0.0.1"

:menu
cls
echo.
echo 1.Install DS# Programming Language 
echo 2.Uninstall DS# Programming Language
echo 3.Exit
echo.

set /p choice=Type option (1-3) and press (Enter):
if "%choice%" == "1" goto install
if "%choice%" == "2" goto uninstall
if "%choice%" == "3" goto end
goto menu

:install
echo Downloading DS# Programming Language...
curl https://raw.githubusercontent.com/AlyGame/DS-Language/src/main.ds --output main.ds
echo Installing DS# Programming Language...
copy main.ds C:\MinGW\include
echo Installation of DS# programming language version %DS_HEADER_VERSION% is complete! :)
echo Please restart your computer to complete the installation!
pause
goto menu

:uninstall
echo Uninstalling DS# Programming Language...
del C:\MinGW\include\main.ds
echo The removal process is complete!
echo DS# version %DS_HEADER_VERSION% has been uninstalled from your computer!
pause
goto menu

:end
exit
